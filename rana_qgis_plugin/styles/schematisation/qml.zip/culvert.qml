<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis maxScale="0" autoRefreshTime="0" simplifyMaxScale="1" hasScaleBasedVisibilityFlag="0" autoRefreshMode="Disabled" labelsEnabled="0" simplifyDrawingHints="1" symbologyReferenceScale="-1" simplifyAlgorithm="0" simplifyDrawingTol="1" minScale="100000000" version="3.44.11-Solothurn" styleCategories="AllStyleCategories" simplifyLocal="1" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal limitMode="0" enabled="0" startExpression="" accumulate="0" endExpression="" durationField="id" fixedDuration="0" mode="0" startField="" endField="" durationUnit="min">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" zoffset="0" extrusionEnabled="0" binding="Centroid" respectLayerSymbol="1" customToleranceEnabled="0" type="IndividualFeatures" showMarkerSymbolInSurfacePlots="0" zscale="1" symbology="Line" clamping="Terrain">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" alpha="1" type="line" is_animated="0" clip_to_extent="1" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleLine" id="{1c8a52a3-458f-4068-8109-1a198172db42}">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="232,113,141,255,rgb:0.9098039,0.4431373,0.5529412,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" alpha="1" type="fill" is_animated="0" clip_to_extent="1" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="{afb64b43-2a5e-4e37-853b-5e452e0e5ada}">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="232,113,141,255,rgb:0.9098039,0.4431373,0.5529412,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="166,81,101,255,rgb:0.6498512,0.3165179,0.3949645,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" alpha="1" type="marker" is_animated="0" clip_to_extent="1" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{614dcd18-fac2-4cd7-8cd5-8fe494ff6111}">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="232,113,141,255,rgb:0.9098039,0.4431373,0.5529412,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="166,81,101,255,rgb:0.6498512,0.3165179,0.3949645,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" forceraster="0" enableorderby="0" type="singleSymbol" symbollevels="0">
    <symbols>
      <symbol name="0" alpha="1" type="line" is_animated="0" clip_to_extent="1" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleLine" id="{e8e5b3f9-7185-4aae-a280-e368374464f8}">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="105,104,103,255,hsv:0.09697222222222222,0.02612344548714427,0.413519493400473,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="1"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol name="" alpha="1" type="line" is_animated="0" clip_to_extent="1" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleLine" id="{30e47569-6f31-4ab9-a9bc-5ad37c14d7b5}">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.26"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="id" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="display_name" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="code" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="exchange_type" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="friction_value" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="friction_type" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="calculation_point_distance" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="discharge_coefficient_positive" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="discharge_coefficient_negative" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="invert_level_start" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="invert_level_end" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="connection_node_id_start" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="connection_node_id_end" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_table" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_shape" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_width" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_height" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tags" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="material_id" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="id"/>
    <alias index="1" name="" field="display_name"/>
    <alias index="2" name="" field="code"/>
    <alias index="3" name="" field="exchange_type"/>
    <alias index="4" name="" field="friction_value"/>
    <alias index="5" name="" field="friction_type"/>
    <alias index="6" name="" field="calculation_point_distance"/>
    <alias index="7" name="" field="discharge_coefficient_positive"/>
    <alias index="8" name="" field="discharge_coefficient_negative"/>
    <alias index="9" name="" field="invert_level_start"/>
    <alias index="10" name="" field="invert_level_end"/>
    <alias index="11" name="" field="connection_node_id_start"/>
    <alias index="12" name="" field="connection_node_id_end"/>
    <alias index="13" name="" field="cross_section_table"/>
    <alias index="14" name="" field="cross_section_shape"/>
    <alias index="15" name="" field="cross_section_width"/>
    <alias index="16" name="" field="cross_section_height"/>
    <alias index="17" name="" field="tags"/>
    <alias index="18" name="" field="material_id"/>
  </aliases>
  <defaults>
    <default expression="" applyOnUpdate="0" field="id"/>
    <default expression="" applyOnUpdate="0" field="display_name"/>
    <default expression="" applyOnUpdate="0" field="code"/>
    <default expression="" applyOnUpdate="0" field="exchange_type"/>
    <default expression="" applyOnUpdate="0" field="friction_value"/>
    <default expression="" applyOnUpdate="0" field="friction_type"/>
    <default expression="" applyOnUpdate="0" field="calculation_point_distance"/>
    <default expression="" applyOnUpdate="0" field="discharge_coefficient_positive"/>
    <default expression="" applyOnUpdate="0" field="discharge_coefficient_negative"/>
    <default expression="" applyOnUpdate="0" field="invert_level_start"/>
    <default expression="" applyOnUpdate="0" field="invert_level_end"/>
    <default expression="" applyOnUpdate="0" field="connection_node_id_start"/>
    <default expression="" applyOnUpdate="0" field="connection_node_id_end"/>
    <default expression="" applyOnUpdate="0" field="cross_section_table"/>
    <default expression="" applyOnUpdate="0" field="cross_section_shape"/>
    <default expression="" applyOnUpdate="0" field="cross_section_width"/>
    <default expression="" applyOnUpdate="0" field="cross_section_height"/>
    <default expression="" applyOnUpdate="0" field="tags"/>
    <default expression="" applyOnUpdate="0" field="material_id"/>
  </defaults>
  <constraints>
    <constraint constraints="3" unique_strength="1" notnull_strength="1" exp_strength="0" field="id"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="display_name"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="code"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="exchange_type"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="friction_value"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="friction_type"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="calculation_point_distance"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="discharge_coefficient_positive"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="discharge_coefficient_negative"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="invert_level_start"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="invert_level_end"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="connection_node_id_start"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="connection_node_id_end"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="cross_section_table"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="cross_section_shape"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="cross_section_width"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="cross_section_height"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="tags"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="material_id"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="id"/>
    <constraint desc="" exp="" field="display_name"/>
    <constraint desc="" exp="" field="code"/>
    <constraint desc="" exp="" field="exchange_type"/>
    <constraint desc="" exp="" field="friction_value"/>
    <constraint desc="" exp="" field="friction_type"/>
    <constraint desc="" exp="" field="calculation_point_distance"/>
    <constraint desc="" exp="" field="discharge_coefficient_positive"/>
    <constraint desc="" exp="" field="discharge_coefficient_negative"/>
    <constraint desc="" exp="" field="invert_level_start"/>
    <constraint desc="" exp="" field="invert_level_end"/>
    <constraint desc="" exp="" field="connection_node_id_start"/>
    <constraint desc="" exp="" field="connection_node_id_end"/>
    <constraint desc="" exp="" field="cross_section_table"/>
    <constraint desc="" exp="" field="cross_section_shape"/>
    <constraint desc="" exp="" field="cross_section_width"/>
    <constraint desc="" exp="" field="cross_section_height"/>
    <constraint desc="" exp="" field="tags"/>
    <constraint desc="" exp="" field="material_id"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortExpression="" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column name="id" type="field" width="-1" hidden="0"/>
      <column name="display_name" type="field" width="-1" hidden="0"/>
      <column name="code" type="field" width="-1" hidden="0"/>
      <column name="exchange_type" type="field" width="-1" hidden="0"/>
      <column name="friction_value" type="field" width="-1" hidden="0"/>
      <column name="friction_type" type="field" width="-1" hidden="0"/>
      <column name="calculation_point_distance" type="field" width="-1" hidden="0"/>
      <column name="discharge_coefficient_positive" type="field" width="-1" hidden="0"/>
      <column name="discharge_coefficient_negative" type="field" width="-1" hidden="0"/>
      <column name="invert_level_start" type="field" width="-1" hidden="0"/>
      <column name="invert_level_end" type="field" width="-1" hidden="0"/>
      <column name="connection_node_id_start" type="field" width="-1" hidden="0"/>
      <column name="connection_node_id_end" type="field" width="-1" hidden="0"/>
      <column name="cross_section_table" type="field" width="-1" hidden="0"/>
      <column name="cross_section_shape" type="field" width="-1" hidden="0"/>
      <column name="cross_section_width" type="field" width="-1" hidden="0"/>
      <column name="cross_section_height" type="field" width="-1" hidden="0"/>
      <column name="tags" type="field" width="-1" hidden="0"/>
      <column name="material_id" type="field" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="calculation_point_distance" editable="1"/>
    <field name="code" editable="1"/>
    <field name="connection_node_id_end" editable="1"/>
    <field name="connection_node_id_start" editable="1"/>
    <field name="cross_section_height" editable="1"/>
    <field name="cross_section_shape" editable="1"/>
    <field name="cross_section_table" editable="1"/>
    <field name="cross_section_width" editable="1"/>
    <field name="discharge_coefficient_negative" editable="1"/>
    <field name="discharge_coefficient_positive" editable="1"/>
    <field name="display_name" editable="1"/>
    <field name="exchange_type" editable="1"/>
    <field name="friction_type" editable="1"/>
    <field name="friction_value" editable="1"/>
    <field name="id" editable="1"/>
    <field name="invert_level_end" editable="1"/>
    <field name="invert_level_start" editable="1"/>
    <field name="material_id" editable="1"/>
    <field name="tags" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="calculation_point_distance" labelOnTop="0"/>
    <field name="code" labelOnTop="0"/>
    <field name="connection_node_id_end" labelOnTop="0"/>
    <field name="connection_node_id_start" labelOnTop="0"/>
    <field name="cross_section_height" labelOnTop="0"/>
    <field name="cross_section_shape" labelOnTop="0"/>
    <field name="cross_section_table" labelOnTop="0"/>
    <field name="cross_section_width" labelOnTop="0"/>
    <field name="discharge_coefficient_negative" labelOnTop="0"/>
    <field name="discharge_coefficient_positive" labelOnTop="0"/>
    <field name="display_name" labelOnTop="0"/>
    <field name="exchange_type" labelOnTop="0"/>
    <field name="friction_type" labelOnTop="0"/>
    <field name="friction_value" labelOnTop="0"/>
    <field name="id" labelOnTop="0"/>
    <field name="invert_level_end" labelOnTop="0"/>
    <field name="invert_level_start" labelOnTop="0"/>
    <field name="material_id" labelOnTop="0"/>
    <field name="tags" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="calculation_point_distance" reuseLastValue="0"/>
    <field name="code" reuseLastValue="0"/>
    <field name="connection_node_id_end" reuseLastValue="0"/>
    <field name="connection_node_id_start" reuseLastValue="0"/>
    <field name="cross_section_height" reuseLastValue="0"/>
    <field name="cross_section_shape" reuseLastValue="0"/>
    <field name="cross_section_table" reuseLastValue="0"/>
    <field name="cross_section_width" reuseLastValue="0"/>
    <field name="discharge_coefficient_negative" reuseLastValue="0"/>
    <field name="discharge_coefficient_positive" reuseLastValue="0"/>
    <field name="display_name" reuseLastValue="0"/>
    <field name="exchange_type" reuseLastValue="0"/>
    <field name="friction_type" reuseLastValue="0"/>
    <field name="friction_value" reuseLastValue="0"/>
    <field name="id" reuseLastValue="0"/>
    <field name="invert_level_end" reuseLastValue="0"/>
    <field name="invert_level_start" reuseLastValue="0"/>
    <field name="material_id" reuseLastValue="0"/>
    <field name="tags" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"display_name"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
