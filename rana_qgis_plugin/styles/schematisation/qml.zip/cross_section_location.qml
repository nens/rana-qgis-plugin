<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis symbologyReferenceScale="-1" hasScaleBasedVisibilityFlag="0" minScale="0" autoRefreshTime="0" simplifyDrawingTol="1" readOnly="0" simplifyMaxScale="1" simplifyDrawingHints="0" labelsEnabled="0" simplifyAlgorithm="0" styleCategories="AllStyleCategories" maxScale="0" autoRefreshMode="Disabled" version="3.40.6-Bratislava" simplifyLocal="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>0</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endExpression="" fixedDuration="0" durationField="id" startExpression="" durationUnit="min" enabled="0" accumulate="0" mode="0" startField="" endField="" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" zoffset="0" zscale="1" clamping="Terrain" symbology="Line" showMarkerSymbolInSurfacePlots="0" extrusionEnabled="0" extrusion="0" respectLayerSymbol="1" type="IndividualFeatures">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol frame_rate="10" alpha="1" clip_to_extent="1" is_animated="0" name="" force_rhr="0" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="0" id="{4d6f6583-a89b-46e3-9189-8d9709c9dbf3}" locked="0" enabled="1">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="231,113,72,255,rgb:0.90588235294117647,0.44313725490196076,0.28235294117647058,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol frame_rate="10" alpha="1" clip_to_extent="1" is_animated="0" name="" force_rhr="0" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" pass="0" id="{664245b7-a7b1-4319-ab19-b3357be394a5}" locked="0" enabled="1">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="231,113,72,255,rgb:0.90588235294117647,0.44313725490196076,0.28235294117647058,1" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="165,81,51,255,rgb:0.6470588235294118,0.31651789120317386,0.20167849240863661,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol frame_rate="10" alpha="1" clip_to_extent="1" is_animated="0" name="" force_rhr="0" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" pass="0" id="{63675338-d9e1-46a7-a9a1-98d8857f480c}" locked="0" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="231,113,72,255,rgb:0.90588235294117647,0.44313725490196076,0.28235294117647058,1" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="165,81,51,255,rgb:0.6470588235294118,0.31651789120317386,0.20167849240863661,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" symbollevels="0" type="singleSymbol" forceraster="0" enableorderby="0">
    <symbols>
      <symbol frame_rate="10" alpha="1" clip_to_extent="1" is_animated="0" name="0" force_rhr="0" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" pass="0" id="{8396075e-919c-4709-8515-bb67ad61a272}" locked="0" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="19,61,142,255,rgb:0.07450980392156863,0.23921568627450981,0.55686274509803924,1" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255,rgb:0,0,0,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="2" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="size" type="Map">
                  <Option value="false" name="active" type="bool"/>
                  <Option value="if(@map_scale&lt;10000, 2,0.5)" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol frame_rate="10" alpha="1" clip_to_extent="1" is_animated="0" name="" force_rhr="0" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" pass="0" id="{a1ab33be-da1e-4117-ba85-afdb5061adf7}" locked="0" enabled="1">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,0,0,255,rgb:1,0,0,1" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="2" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option value="0" name="embeddedWidgets/count" type="int"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="id" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option value="false" name="AllowNull" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="code" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="reference_level" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="1.7976931348623157e+308" name="Max" type="double"/>
            <Option value="-1.7976931348623157e+308" name="Min" type="double"/>
            <Option value="3" name="Precision" type="int"/>
            <Option value="1" name="Step" type="double"/>
            <Option value="SpinBox" name="Style" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="friction_type" configurationFlags="NoFlag">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" name="" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="1" name="1: Chezy" type="int"/>
              </Option>
              <Option type="Map">
                <Option value="2" name="2: Manning" type="int"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="friction_value" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option value="false" name="AllowNull" type="bool"/>
            <Option value="1000000000000000" name="Max" type="qlonglong"/>
            <Option value="-1000000000000000" name="Min" type="qlonglong"/>
            <Option value="3" name="Precision" type="int"/>
            <Option value="1" name="Step" type="double"/>
            <Option value="SpinBox" name="Style" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="bank_level" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="1000000000000000" name="Max" type="qlonglong"/>
            <Option value="-1000000000000000" name="Min" type="qlonglong"/>
            <Option value="3" name="Precision" type="int"/>
            <Option value="1" name="Step" type="double"/>
            <Option value="SpinBox" name="Style" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="channel_id" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option value="false" name="AllowNull" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="vegetation_stem_density" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="1000000000000000" name="Max" type="qlonglong"/>
            <Option value="-1000000000000000" name="Min" type="qlonglong"/>
            <Option value="3" name="Precision" type="int"/>
            <Option value="1" name="Step" type="double"/>
            <Option value="SpinBox" name="Style" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="vegetation_stem_diameter" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="1000000000000000" name="Max" type="qlonglong"/>
            <Option value="-1000000000000000" name="Min" type="qlonglong"/>
            <Option value="3" name="Precision" type="int"/>
            <Option value="1" name="Step" type="double"/>
            <Option value="SpinBox" name="Style" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="vegetation_height" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="1000000000000000" name="Max" type="qlonglong"/>
            <Option value="-1000000000000000" name="Min" type="qlonglong"/>
            <Option value="3" name="Precision" type="int"/>
            <Option value="1" name="Step" type="double"/>
            <Option value="SpinBox" name="Style" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="vegetation_drag_coefficient" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="1000000000000000" name="Max" type="qlonglong"/>
            <Option value="-1000000000000000" name="Min" type="qlonglong"/>
            <Option value="3" name="Precision" type="int"/>
            <Option value="1" name="Step" type="double"/>
            <Option value="SpinBox" name="Style" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_table" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_friction_values" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_vegetation_table" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_shape" configurationFlags="NoFlag">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" name="" type="QString"/>
              </Option>
              <Option type="Map">
                <Option value="0" name="0: Closed rectangle" type="int"/>
              </Option>
              <Option type="Map">
                <Option value="1" name="1: Open rectangle" type="int"/>
              </Option>
              <Option type="Map">
                <Option value="2" name="2: Circle" type="int"/>
              </Option>
              <Option type="Map">
                <Option value="3" name="3: Egg" type="int"/>
              </Option>
              <Option type="Map">
                <Option value="5" name="5: Tabulated rectangle" type="int"/>
              </Option>
              <Option type="Map">
                <Option value="6" name="6: Tabulated trapezium" type="int"/>
              </Option>
              <Option type="Map">
                <Option value="7" name="7: YZ" type="int"/>
              </Option>
              <Option type="Map">
                <Option value="8" name="8: Inverted egg" type="int"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_width" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="1000000000000000" name="Max" type="qlonglong"/>
            <Option value="-1000000000000000" name="Min" type="qlonglong"/>
            <Option value="3" name="Precision" type="int"/>
            <Option value="1" name="Step" type="double"/>
            <Option value="SpinBox" name="Style" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="cross_section_height" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="1000000000000000" name="Max" type="qlonglong"/>
            <Option value="-1000000000000000" name="Min" type="qlonglong"/>
            <Option value="3" name="Precision" type="int"/>
            <Option value="1" name="Step" type="double"/>
            <Option value="SpinBox" name="Style" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="tags" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="display_name" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="ID" field="id"/>
    <alias index="1" name="Code" field="code"/>
    <alias index="2" name="Reference level [m MSL]" field="reference_level"/>
    <alias index="3" name="Friction type" field="friction_type"/>
    <alias index="4" name="Friction value" field="friction_value"/>
    <alias index="5" name="Bank level [m MSL]" field="bank_level"/>
    <alias index="6" name="Channel ID" field="channel_id"/>
    <alias index="7" name="Vegetation stem density [m⁻²]" field="vegetation_stem_density"/>
    <alias index="8" name="Vegetation stem diameter [m]" field="vegetation_stem_diameter"/>
    <alias index="9" name="Vegetation height [m]" field="vegetation_height"/>
    <alias index="10" name="Vegetation drag coefficient" field="vegetation_drag_coefficient"/>
    <alias index="11" name="Cross-section table" field="cross_section_table"/>
    <alias index="12" name="Cross-section values" field="cross_section_friction_values"/>
    <alias index="13" name="Cross-section vegetation table" field="cross_section_vegetation_table"/>
    <alias index="14" name="Cross-section shape" field="cross_section_shape"/>
    <alias index="15" name="Cross-section width [m]" field="cross_section_width"/>
    <alias index="16" name="Cross-section height [m]" field="cross_section_height"/>
    <alias index="17" name="" field="tags"/>
    <alias index="18" name="" field="display_name"/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="id"/>
    <policy policy="Duplicate" field="code"/>
    <policy policy="Duplicate" field="reference_level"/>
    <policy policy="Duplicate" field="friction_type"/>
    <policy policy="Duplicate" field="friction_value"/>
    <policy policy="Duplicate" field="bank_level"/>
    <policy policy="Duplicate" field="channel_id"/>
    <policy policy="Duplicate" field="vegetation_stem_density"/>
    <policy policy="Duplicate" field="vegetation_stem_diameter"/>
    <policy policy="Duplicate" field="vegetation_height"/>
    <policy policy="Duplicate" field="vegetation_drag_coefficient"/>
    <policy policy="Duplicate" field="cross_section_table"/>
    <policy policy="Duplicate" field="cross_section_friction_values"/>
    <policy policy="Duplicate" field="cross_section_vegetation_table"/>
    <policy policy="Duplicate" field="cross_section_shape"/>
    <policy policy="Duplicate" field="cross_section_width"/>
    <policy policy="Duplicate" field="cross_section_height"/>
    <policy policy="Duplicate" field="tags"/>
    <policy policy="Duplicate" field="display_name"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy policy="Duplicate" field="id"/>
    <policy policy="Duplicate" field="code"/>
    <policy policy="Duplicate" field="reference_level"/>
    <policy policy="Duplicate" field="friction_type"/>
    <policy policy="Duplicate" field="friction_value"/>
    <policy policy="Duplicate" field="bank_level"/>
    <policy policy="Duplicate" field="channel_id"/>
    <policy policy="Duplicate" field="vegetation_stem_density"/>
    <policy policy="Duplicate" field="vegetation_stem_diameter"/>
    <policy policy="Duplicate" field="vegetation_height"/>
    <policy policy="Duplicate" field="vegetation_drag_coefficient"/>
    <policy policy="Duplicate" field="cross_section_table"/>
    <policy policy="Duplicate" field="cross_section_friction_values"/>
    <policy policy="Duplicate" field="cross_section_vegetation_table"/>
    <policy policy="Duplicate" field="cross_section_shape"/>
    <policy policy="Duplicate" field="cross_section_width"/>
    <policy policy="Duplicate" field="cross_section_height"/>
    <policy policy="Duplicate" field="tags"/>
    <policy policy="Duplicate" field="display_name"/>
  </duplicatePolicies>
  <defaults>
    <default expression="" applyOnUpdate="0" field="id"/>
    <default expression="" applyOnUpdate="0" field="code"/>
    <default expression="" applyOnUpdate="0" field="reference_level"/>
    <default expression="" applyOnUpdate="0" field="friction_type"/>
    <default expression="" applyOnUpdate="0" field="friction_value"/>
    <default expression="" applyOnUpdate="0" field="bank_level"/>
    <default expression="" applyOnUpdate="0" field="channel_id"/>
    <default expression="" applyOnUpdate="0" field="vegetation_stem_density"/>
    <default expression="" applyOnUpdate="0" field="vegetation_stem_diameter"/>
    <default expression="" applyOnUpdate="0" field="vegetation_height"/>
    <default expression="" applyOnUpdate="0" field="vegetation_drag_coefficient"/>
    <default expression="" applyOnUpdate="0" field="cross_section_table"/>
    <default expression="" applyOnUpdate="0" field="cross_section_friction_values"/>
    <default expression="" applyOnUpdate="0" field="cross_section_vegetation_table"/>
    <default expression="" applyOnUpdate="0" field="cross_section_shape"/>
    <default expression="" applyOnUpdate="0" field="cross_section_width"/>
    <default expression="" applyOnUpdate="0" field="cross_section_height"/>
    <default expression="" applyOnUpdate="0" field="tags"/>
    <default expression="" applyOnUpdate="0" field="display_name"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" unique_strength="1" constraints="3" field="id" notnull_strength="1"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="code" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="reference_level" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="friction_type" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="friction_value" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="bank_level" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="channel_id" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="vegetation_stem_density" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="vegetation_stem_diameter" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="vegetation_height" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="vegetation_drag_coefficient" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="cross_section_table" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="cross_section_friction_values" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="cross_section_vegetation_table" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="cross_section_shape" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="cross_section_width" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="cross_section_height" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="tags" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="display_name" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="id"/>
    <constraint desc="" exp="" field="code"/>
    <constraint desc="" exp="" field="reference_level"/>
    <constraint desc="" exp="" field="friction_type"/>
    <constraint desc="" exp="" field="friction_value"/>
    <constraint desc="" exp="" field="bank_level"/>
    <constraint desc="" exp="" field="channel_id"/>
    <constraint desc="" exp="" field="vegetation_stem_density"/>
    <constraint desc="" exp="" field="vegetation_stem_diameter"/>
    <constraint desc="" exp="" field="vegetation_height"/>
    <constraint desc="" exp="" field="vegetation_drag_coefficient"/>
    <constraint desc="" exp="" field="cross_section_table"/>
    <constraint desc="" exp="" field="cross_section_friction_values"/>
    <constraint desc="" exp="" field="cross_section_vegetation_table"/>
    <constraint desc="" exp="" field="cross_section_shape"/>
    <constraint desc="" exp="" field="cross_section_width"/>
    <constraint desc="" exp="" field="cross_section_height"/>
    <constraint desc="" exp="" field="tags"/>
    <constraint desc="" exp="" field="display_name"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortExpression="" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column hidden="0" name="id" type="field" width="-1"/>
      <column hidden="0" name="code" type="field" width="-1"/>
      <column hidden="0" name="reference_level" type="field" width="-1"/>
      <column hidden="0" name="friction_type" type="field" width="-1"/>
      <column hidden="0" name="friction_value" type="field" width="-1"/>
      <column hidden="0" name="bank_level" type="field" width="-1"/>
      <column hidden="0" name="channel_id" type="field" width="-1"/>
      <column hidden="0" name="cross_section_shape" type="field" width="-1"/>
      <column hidden="0" name="cross_section_width" type="field" width="-1"/>
      <column hidden="0" name="cross_section_height" type="field" width="-1"/>
      <column hidden="0" name="cross_section_table" type="field" width="110"/>
      <column hidden="0" name="vegetation_stem_density" type="field" width="143"/>
      <column hidden="0" name="vegetation_stem_diameter" type="field" width="-1"/>
      <column hidden="0" name="vegetation_height" type="field" width="-1"/>
      <column hidden="0" name="vegetation_drag_coefficient" type="field" width="-1"/>
      <column hidden="0" name="cross_section_vegetation_table" type="field" width="-1"/>
      <column hidden="0" name="cross_section_friction_values" type="field" width="-1"/>
      <column hidden="0" name="tags" type="field" width="-1"/>
      <column hidden="0" name="display_name" type="field" width="-1"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">C:\Users\jonas.vanschrojenste\AppData\Roaming\Rana\QGIS3\profiles\Demo\python\plugins\threedi_schematisation_editor\forms\ui\cross_section_location.ui</editform>
  <editforminit>open_edit_form</editforminit>
  <editforminitcodesource>2</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[from threedi_schematisation_editor.utils import open_edit_form]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>uifilelayout</editorlayout>
  <editable>
    <field editable="1" name="bank_level"/>
    <field editable="1" name="channel_id"/>
    <field editable="1" name="code"/>
    <field editable="1" name="cross_section_friction_values"/>
    <field editable="1" name="cross_section_height"/>
    <field editable="1" name="cross_section_shape"/>
    <field editable="1" name="cross_section_table"/>
    <field editable="1" name="cross_section_vegetation_table"/>
    <field editable="1" name="cross_section_width"/>
    <field editable="1" name="display_name"/>
    <field editable="1" name="friction_type"/>
    <field editable="1" name="friction_value"/>
    <field editable="1" name="id"/>
    <field editable="1" name="reference_level"/>
    <field editable="1" name="tags"/>
    <field editable="1" name="vegetation_drag_coefficient"/>
    <field editable="1" name="vegetation_height"/>
    <field editable="1" name="vegetation_stem_density"/>
    <field editable="1" name="vegetation_stem_diameter"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="bank_level"/>
    <field labelOnTop="0" name="channel_id"/>
    <field labelOnTop="0" name="code"/>
    <field labelOnTop="0" name="cross_section_friction_values"/>
    <field labelOnTop="0" name="cross_section_height"/>
    <field labelOnTop="0" name="cross_section_shape"/>
    <field labelOnTop="0" name="cross_section_table"/>
    <field labelOnTop="0" name="cross_section_vegetation_table"/>
    <field labelOnTop="0" name="cross_section_width"/>
    <field labelOnTop="0" name="display_name"/>
    <field labelOnTop="0" name="friction_type"/>
    <field labelOnTop="0" name="friction_value"/>
    <field labelOnTop="0" name="id"/>
    <field labelOnTop="0" name="reference_level"/>
    <field labelOnTop="0" name="tags"/>
    <field labelOnTop="0" name="vegetation_drag_coefficient"/>
    <field labelOnTop="0" name="vegetation_height"/>
    <field labelOnTop="0" name="vegetation_stem_density"/>
    <field labelOnTop="0" name="vegetation_stem_diameter"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="bank_level"/>
    <field reuseLastValue="0" name="channel_id"/>
    <field reuseLastValue="0" name="code"/>
    <field reuseLastValue="0" name="cross_section_friction_values"/>
    <field reuseLastValue="0" name="cross_section_height"/>
    <field reuseLastValue="0" name="cross_section_shape"/>
    <field reuseLastValue="0" name="cross_section_table"/>
    <field reuseLastValue="0" name="cross_section_vegetation_table"/>
    <field reuseLastValue="0" name="cross_section_width"/>
    <field reuseLastValue="0" name="display_name"/>
    <field reuseLastValue="0" name="friction_type"/>
    <field reuseLastValue="0" name="friction_value"/>
    <field reuseLastValue="0" name="id"/>
    <field reuseLastValue="0" name="reference_level"/>
    <field reuseLastValue="0" name="tags"/>
    <field reuseLastValue="0" name="vegetation_drag_coefficient"/>
    <field reuseLastValue="0" name="vegetation_height"/>
    <field reuseLastValue="0" name="vegetation_stem_density"/>
    <field reuseLastValue="0" name="vegetation_stem_diameter"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>coalesce(display_name, '') || ' (ID ' || id || ')'</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
