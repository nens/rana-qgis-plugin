<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="0" simplifyDrawingTol="1" simplifyLocal="1" version="3.40.6-Bratislava" autoRefreshMode="Disabled" autoRefreshTime="0" maxScale="0" minScale="0" readOnly="0" hasScaleBasedVisibilityFlag="0" styleCategories="AllStyleCategories" labelsEnabled="0" simplifyMaxScale="1" symbologyReferenceScale="-1" simplifyAlgorithm="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal limitMode="0" endField="" startExpression="" durationField="id" accumulate="0" endExpression="" durationUnit="min" mode="0" fixedDuration="0" startField="" enabled="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" extrusionEnabled="0" symbology="Line" zscale="1" binding="Centroid" type="IndividualFeatures" clamping="Terrain" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" zoffset="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol frame_rate="10" clip_to_extent="1" type="line" force_rhr="0" alpha="1" is_animated="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleLine" id="{4d6f6583-a89b-46e3-9189-8d9709c9dbf3}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="231,113,72,255,rgb:0.90588235294117647,0.44313725490196076,0.28235294117647058,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol frame_rate="10" clip_to_extent="1" type="fill" force_rhr="0" alpha="1" is_animated="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleFill" id="{664245b7-a7b1-4319-ab19-b3357be394a5}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="231,113,72,255,rgb:0.90588235294117647,0.44313725490196076,0.28235294117647058,1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="165,81,51,255,rgb:0.6470588235294118,0.31651789120317386,0.20167849240863661,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol frame_rate="10" clip_to_extent="1" type="marker" force_rhr="0" alpha="1" is_animated="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" id="{63675338-d9e1-46a7-a9a1-98d8857f480c}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="231,113,72,255,rgb:0.90588235294117647,0.44313725490196076,0.28235294117647058,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="165,81,51,255,rgb:0.6470588235294118,0.31651789120317386,0.20167849240863661,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 forceraster="0" enableorderby="0" type="singleSymbol" symbollevels="0" referencescale="-1">
    <symbols>
      <symbol frame_rate="10" clip_to_extent="1" type="marker" force_rhr="0" alpha="1" is_animated="0" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" id="{8396075e-919c-4709-8515-bb67ad61a272}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="19,61,142,255,rgb:0.07450980392156863,0.23921568627450981,0.55686274509803924,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="2"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option type="Map" name="properties">
                <Option type="Map" name="size">
                  <Option type="bool" name="active" value="false"/>
                  <Option type="QString" name="expression" value="if(@map_scale&lt;10000, 2,0.5)"/>
                  <Option type="int" name="type" value="3"/>
                </Option>
              </Option>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol frame_rate="10" clip_to_extent="1" type="marker" force_rhr="0" alpha="1" is_animated="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" id="{a1ab33be-da1e-4117-ba85-afdb5061adf7}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="255,0,0,255,rgb:1,0,0,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="circle"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="2"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option type="int" name="embeddedWidgets/count" value="0"/>
      <Option type="invalid" name="variableNames"/>
      <Option type="invalid" name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="id">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="code">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="reference_level">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="friction_type">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="friction_value">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="bank_level">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="channel_id">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="vegetation_stem_density">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="vegetation_stem_diameter">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="vegetation_height">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="vegetation_drag_coefficient">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_table">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_friction_values">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_vegetation_table">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_shape">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_width">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_height">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="display_name">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="id" name="" index="0"/>
    <alias field="code" name="" index="1"/>
    <alias field="reference_level" name="" index="2"/>
    <alias field="friction_type" name="" index="3"/>
    <alias field="friction_value" name="" index="4"/>
    <alias field="bank_level" name="" index="5"/>
    <alias field="channel_id" name="" index="6"/>
    <alias field="vegetation_stem_density" name="" index="7"/>
    <alias field="vegetation_stem_diameter" name="" index="8"/>
    <alias field="vegetation_height" name="" index="9"/>
    <alias field="vegetation_drag_coefficient" name="" index="10"/>
    <alias field="cross_section_table" name="" index="11"/>
    <alias field="cross_section_friction_values" name="" index="12"/>
    <alias field="cross_section_vegetation_table" name="" index="13"/>
    <alias field="cross_section_shape" name="" index="14"/>
    <alias field="cross_section_width" name="" index="15"/>
    <alias field="cross_section_height" name="" index="16"/>
    <alias field="tags" name="" index="17"/>
    <alias field="display_name" name="" index="18"/>
  </aliases>
  <splitPolicies>
    <policy field="id" policy="Duplicate"/>
    <policy field="code" policy="Duplicate"/>
    <policy field="reference_level" policy="Duplicate"/>
    <policy field="friction_type" policy="Duplicate"/>
    <policy field="friction_value" policy="Duplicate"/>
    <policy field="bank_level" policy="Duplicate"/>
    <policy field="channel_id" policy="Duplicate"/>
    <policy field="vegetation_stem_density" policy="Duplicate"/>
    <policy field="vegetation_stem_diameter" policy="Duplicate"/>
    <policy field="vegetation_height" policy="Duplicate"/>
    <policy field="vegetation_drag_coefficient" policy="Duplicate"/>
    <policy field="cross_section_table" policy="Duplicate"/>
    <policy field="cross_section_friction_values" policy="Duplicate"/>
    <policy field="cross_section_vegetation_table" policy="Duplicate"/>
    <policy field="cross_section_shape" policy="Duplicate"/>
    <policy field="cross_section_width" policy="Duplicate"/>
    <policy field="cross_section_height" policy="Duplicate"/>
    <policy field="tags" policy="Duplicate"/>
    <policy field="display_name" policy="Duplicate"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy field="id" policy="Duplicate"/>
    <policy field="code" policy="Duplicate"/>
    <policy field="reference_level" policy="Duplicate"/>
    <policy field="friction_type" policy="Duplicate"/>
    <policy field="friction_value" policy="Duplicate"/>
    <policy field="bank_level" policy="Duplicate"/>
    <policy field="channel_id" policy="Duplicate"/>
    <policy field="vegetation_stem_density" policy="Duplicate"/>
    <policy field="vegetation_stem_diameter" policy="Duplicate"/>
    <policy field="vegetation_height" policy="Duplicate"/>
    <policy field="vegetation_drag_coefficient" policy="Duplicate"/>
    <policy field="cross_section_table" policy="Duplicate"/>
    <policy field="cross_section_friction_values" policy="Duplicate"/>
    <policy field="cross_section_vegetation_table" policy="Duplicate"/>
    <policy field="cross_section_shape" policy="Duplicate"/>
    <policy field="cross_section_width" policy="Duplicate"/>
    <policy field="cross_section_height" policy="Duplicate"/>
    <policy field="tags" policy="Duplicate"/>
    <policy field="display_name" policy="Duplicate"/>
  </duplicatePolicies>
  <defaults>
    <default field="id" expression="" applyOnUpdate="0"/>
    <default field="code" expression="" applyOnUpdate="0"/>
    <default field="reference_level" expression="" applyOnUpdate="0"/>
    <default field="friction_type" expression="" applyOnUpdate="0"/>
    <default field="friction_value" expression="" applyOnUpdate="0"/>
    <default field="bank_level" expression="" applyOnUpdate="0"/>
    <default field="channel_id" expression="" applyOnUpdate="0"/>
    <default field="vegetation_stem_density" expression="" applyOnUpdate="0"/>
    <default field="vegetation_stem_diameter" expression="" applyOnUpdate="0"/>
    <default field="vegetation_height" expression="" applyOnUpdate="0"/>
    <default field="vegetation_drag_coefficient" expression="" applyOnUpdate="0"/>
    <default field="cross_section_table" expression="" applyOnUpdate="0"/>
    <default field="cross_section_friction_values" expression="" applyOnUpdate="0"/>
    <default field="cross_section_vegetation_table" expression="" applyOnUpdate="0"/>
    <default field="cross_section_shape" expression="" applyOnUpdate="0"/>
    <default field="cross_section_width" expression="" applyOnUpdate="0"/>
    <default field="cross_section_height" expression="" applyOnUpdate="0"/>
    <default field="tags" expression="" applyOnUpdate="0"/>
    <default field="display_name" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="id" unique_strength="1" exp_strength="0" constraints="3" notnull_strength="1"/>
    <constraint field="code" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="reference_level" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="friction_type" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="friction_value" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="bank_level" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="channel_id" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="vegetation_stem_density" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="vegetation_stem_diameter" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="vegetation_height" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="vegetation_drag_coefficient" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_table" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_friction_values" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_vegetation_table" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_shape" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_width" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_height" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="tags" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="display_name" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="id" exp="" desc=""/>
    <constraint field="code" exp="" desc=""/>
    <constraint field="reference_level" exp="" desc=""/>
    <constraint field="friction_type" exp="" desc=""/>
    <constraint field="friction_value" exp="" desc=""/>
    <constraint field="bank_level" exp="" desc=""/>
    <constraint field="channel_id" exp="" desc=""/>
    <constraint field="vegetation_stem_density" exp="" desc=""/>
    <constraint field="vegetation_stem_diameter" exp="" desc=""/>
    <constraint field="vegetation_height" exp="" desc=""/>
    <constraint field="vegetation_drag_coefficient" exp="" desc=""/>
    <constraint field="cross_section_table" exp="" desc=""/>
    <constraint field="cross_section_friction_values" exp="" desc=""/>
    <constraint field="cross_section_vegetation_table" exp="" desc=""/>
    <constraint field="cross_section_shape" exp="" desc=""/>
    <constraint field="cross_section_width" exp="" desc=""/>
    <constraint field="cross_section_height" exp="" desc=""/>
    <constraint field="tags" exp="" desc=""/>
    <constraint field="display_name" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column width="-1" type="field" hidden="0" name="id"/>
      <column width="-1" type="field" hidden="0" name="code"/>
      <column width="-1" type="field" hidden="0" name="reference_level"/>
      <column width="-1" type="field" hidden="0" name="friction_type"/>
      <column width="-1" type="field" hidden="0" name="friction_value"/>
      <column width="-1" type="field" hidden="0" name="bank_level"/>
      <column width="-1" type="field" hidden="0" name="channel_id"/>
      <column width="-1" type="field" hidden="0" name="cross_section_shape"/>
      <column width="-1" type="field" hidden="0" name="cross_section_width"/>
      <column width="-1" type="field" hidden="0" name="cross_section_height"/>
      <column width="110" type="field" hidden="0" name="cross_section_table"/>
      <column width="143" type="field" hidden="0" name="vegetation_stem_density"/>
      <column width="-1" type="field" hidden="0" name="vegetation_stem_diameter"/>
      <column width="-1" type="field" hidden="0" name="vegetation_height"/>
      <column width="-1" type="field" hidden="0" name="vegetation_drag_coefficient"/>
      <column width="-1" type="field" hidden="0" name="cross_section_vegetation_table"/>
      <column width="-1" type="field" hidden="0" name="cross_section_friction_values"/>
      <column width="-1" type="field" hidden="0" name="tags"/>
      <column width="-1" type="field" hidden="0" name="display_name"/>
      <column width="-1" type="actions" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="bank_level"/>
    <field editable="1" name="channel_id"/>
    <field editable="1" name="code"/>
    <field editable="1" name="cross_section_friction_values"/>
    <field editable="1" name="cross_section_height"/>
    <field editable="1" name="cross_section_shape"/>
    <field editable="1" name="cross_section_table"/>
    <field editable="1" name="cross_section_vegetation_table"/>
    <field editable="1" name="cross_section_width"/>
    <field editable="1" name="display_name"/>
    <field editable="1" name="friction_type"/>
    <field editable="1" name="friction_value"/>
    <field editable="1" name="id"/>
    <field editable="1" name="reference_level"/>
    <field editable="1" name="tags"/>
    <field editable="1" name="vegetation_drag_coefficient"/>
    <field editable="1" name="vegetation_height"/>
    <field editable="1" name="vegetation_stem_density"/>
    <field editable="1" name="vegetation_stem_diameter"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="bank_level"/>
    <field labelOnTop="0" name="channel_id"/>
    <field labelOnTop="0" name="code"/>
    <field labelOnTop="0" name="cross_section_friction_values"/>
    <field labelOnTop="0" name="cross_section_height"/>
    <field labelOnTop="0" name="cross_section_shape"/>
    <field labelOnTop="0" name="cross_section_table"/>
    <field labelOnTop="0" name="cross_section_vegetation_table"/>
    <field labelOnTop="0" name="cross_section_width"/>
    <field labelOnTop="0" name="display_name"/>
    <field labelOnTop="0" name="friction_type"/>
    <field labelOnTop="0" name="friction_value"/>
    <field labelOnTop="0" name="id"/>
    <field labelOnTop="0" name="reference_level"/>
    <field labelOnTop="0" name="tags"/>
    <field labelOnTop="0" name="vegetation_drag_coefficient"/>
    <field labelOnTop="0" name="vegetation_height"/>
    <field labelOnTop="0" name="vegetation_stem_density"/>
    <field labelOnTop="0" name="vegetation_stem_diameter"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="bank_level"/>
    <field reuseLastValue="0" name="channel_id"/>
    <field reuseLastValue="0" name="code"/>
    <field reuseLastValue="0" name="cross_section_friction_values"/>
    <field reuseLastValue="0" name="cross_section_height"/>
    <field reuseLastValue="0" name="cross_section_shape"/>
    <field reuseLastValue="0" name="cross_section_table"/>
    <field reuseLastValue="0" name="cross_section_vegetation_table"/>
    <field reuseLastValue="0" name="cross_section_width"/>
    <field reuseLastValue="0" name="display_name"/>
    <field reuseLastValue="0" name="friction_type"/>
    <field reuseLastValue="0" name="friction_value"/>
    <field reuseLastValue="0" name="id"/>
    <field reuseLastValue="0" name="reference_level"/>
    <field reuseLastValue="0" name="tags"/>
    <field reuseLastValue="0" name="vegetation_drag_coefficient"/>
    <field reuseLastValue="0" name="vegetation_height"/>
    <field reuseLastValue="0" name="vegetation_stem_density"/>
    <field reuseLastValue="0" name="vegetation_stem_diameter"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>coalesce(display_name, '') || ' (ID ' || id || ')'</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
