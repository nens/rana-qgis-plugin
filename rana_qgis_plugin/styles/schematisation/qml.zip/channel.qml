<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyAlgorithm="0" simplifyDrawingHints="1" simplifyDrawingTol="1" version="3.44.8-Solothurn" minScale="0" autoRefreshMode="Disabled" labelsEnabled="0" readOnly="0" simplifyLocal="1" styleCategories="AllStyleCategories" maxScale="0" autoRefreshTime="0" simplifyMaxScale="1" symbologyReferenceScale="-1" hasScaleBasedVisibilityFlag="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endExpression="" durationUnit="min" durationField="" fixedDuration="0" startField="" accumulate="0" limitMode="0" endField="" enabled="0" startExpression="" mode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" clamping="Terrain" binding="Centroid" type="IndividualFeatures" zoffset="0" extrusionEnabled="0" zscale="1" symbology="Line" extrusion="0" customToleranceEnabled="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol force_rhr="0" type="line" name="" clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" class="SimpleLine" id="{689c998c-81d0-4f44-94f6-4dc57cdad4ff}" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="255,158,23,255,rgb:1,0.6196078,0.0901961,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol force_rhr="0" type="fill" name="" clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" class="SimpleFill" id="{1ef4b093-f0ff-4975-b51e-0b582050b5f8}" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="255,158,23,255,rgb:1,0.6196078,0.0901961,1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="182,113,16,255,rgb:0.7142748,0.4425269,0.0644236,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol force_rhr="0" type="marker" name="" clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" class="SimpleMarker" id="{6c39dd5f-81da-4a6b-b695-04b81c23a214}" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="255,158,23,255,rgb:1,0.6196078,0.0901961,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="182,113,16,255,rgb:0.7142748,0.4425269,0.0644236,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" symbollevels="0" forceraster="0" type="singleSymbol" enableorderby="0">
    <symbols>
      <symbol force_rhr="0" type="line" name="0" clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" class="SimpleLine" id="{68a7e849-22e1-45ee-8770-c619907326d4}" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="173,216,230,255,rgb:0.6784314,0.8470588,0.9019608,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.26"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol force_rhr="0" type="line" name="" clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" class="SimpleLine" id="{11f32db9-f4d5-4b11-b953-7b0dc584901a}" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.26"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option type="int" name="embeddedWidgets/count" value="0"/>
      <Option type="invalid" name="variableNames"/>
      <Option type="invalid" name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="id">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="display_name">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="code">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="exchange_type">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="" value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}"/>
              </Option>
              <Option type="Map">
                <Option type="int" name="100: Embedded" value="100"/>
              </Option>
              <Option type="Map">
                <Option type="int" name="101: Isolated" value="101"/>
              </Option>
              <Option type="Map">
                <Option type="int" name="102: Connected" value="102"/>
              </Option>
              <Option type="Map">
                <Option type="int" name="105: Double connected" value="105"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="calculation_point_distance">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
            <Option type="qlonglong" name="Max" value="1000000000000000"/>
            <Option type="qlonglong" name="Min" value="-1000000000000000"/>
            <Option type="int" name="Precision" value="3"/>
            <Option type="double" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="connection_node_id_start">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="connection_node_id_end">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="exchange_thickness">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
            <Option type="qlonglong" name="Max" value="1000000000000000"/>
            <Option type="qlonglong" name="Min" value="-1000000000000000"/>
            <Option type="int" name="Precision" value="3"/>
            <Option type="double" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="hydraulic_conductivity_in">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
            <Option type="qlonglong" name="Max" value="1000000000000000"/>
            <Option type="int" name="Min" value="0"/>
            <Option type="int" name="Precision" value="3"/>
            <Option type="double" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="hydraulic_conductivity_out">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
            <Option type="qlonglong" name="Max" value="1000000000000000"/>
            <Option type="int" name="Min" value="0"/>
            <Option type="int" name="Precision" value="3"/>
            <Option type="double" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="id" index="0" name="ID"/>
    <alias field="display_name" index="1" name="Display name"/>
    <alias field="code" index="2" name="Code"/>
    <alias field="exchange_type" index="3" name="Exchange type"/>
    <alias field="calculation_point_distance" index="4" name="Calculation point distance [m]"/>
    <alias field="connection_node_id_start" index="5" name="Connection node ID start"/>
    <alias field="connection_node_id_end" index="6" name="Connection node ID end"/>
    <alias field="exchange_thickness" index="7" name="Exchange thickness [m]"/>
    <alias field="hydraulic_conductivity_in" index="8" name="Hydraulic conductivity in [m/d]"/>
    <alias field="hydraulic_conductivity_out" index="9" name="Hydraulic conductivity out [m/d]"/>
    <alias field="tags" index="10" name="Tags"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" field="id" expression=""/>
    <default applyOnUpdate="0" field="display_name" expression=""/>
    <default applyOnUpdate="0" field="code" expression=""/>
    <default applyOnUpdate="0" field="exchange_type" expression=""/>
    <default applyOnUpdate="0" field="calculation_point_distance" expression=""/>
    <default applyOnUpdate="0" field="connection_node_id_start" expression=""/>
    <default applyOnUpdate="0" field="connection_node_id_end" expression=""/>
    <default applyOnUpdate="0" field="exchange_thickness" expression=""/>
    <default applyOnUpdate="0" field="hydraulic_conductivity_in" expression=""/>
    <default applyOnUpdate="0" field="hydraulic_conductivity_out" expression=""/>
    <default applyOnUpdate="0" field="tags" expression=""/>
  </defaults>
  <constraints>
    <constraint constraints="3" unique_strength="1" field="id" exp_strength="0" notnull_strength="1"/>
    <constraint constraints="0" unique_strength="0" field="display_name" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="code" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="exchange_type" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="calculation_point_distance" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="connection_node_id_start" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="connection_node_id_end" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="exchange_thickness" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="hydraulic_conductivity_in" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="hydraulic_conductivity_out" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="tags" exp_strength="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="id" exp="" desc=""/>
    <constraint field="display_name" exp="" desc=""/>
    <constraint field="code" exp="" desc=""/>
    <constraint field="exchange_type" exp="" desc=""/>
    <constraint field="calculation_point_distance" exp="" desc=""/>
    <constraint field="connection_node_id_start" exp="" desc=""/>
    <constraint field="connection_node_id_end" exp="" desc=""/>
    <constraint field="exchange_thickness" exp="" desc=""/>
    <constraint field="hydraulic_conductivity_in" exp="" desc=""/>
    <constraint field="hydraulic_conductivity_out" exp="" desc=""/>
    <constraint field="tags" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="&quot;exchange_thickness&quot;" actionWidgetStyle="dropDown">
    <columns>
      <column hidden="0" width="-1" type="field" name="id"/>
      <column hidden="0" width="-1" type="field" name="code"/>
      <column hidden="0" width="-1" type="field" name="display_name"/>
      <column hidden="0" width="146" type="field" name="connection_node_id_start"/>
      <column hidden="0" width="141" type="field" name="connection_node_id_end"/>
      <column hidden="0" width="174" type="field" name="calculation_point_distance"/>
      <column hidden="0" width="-1" type="field" name="exchange_type"/>
      <column hidden="0" width="158" type="field" name="exchange_thickness"/>
      <column hidden="0" width="203" type="field" name="hydraulic_conductivity_in"/>
      <column hidden="0" width="-1" type="field" name="hydraulic_conductivity_out"/>
      <column hidden="0" width="-1" type="field" name="tags"/>
      <column hidden="1" width="-1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">C:\Users\jonas.vanschrojenste\AppData\Roaming\Rana\QGIS3\profiles\Demo\python\plugins\threedi_schematisation_editor\forms\ui\channel.ui</editform>
  <editforminit>open_edit_form</editforminit>
  <editforminitcodesource>2</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[from threedi_schematisation_editor.utils import open_edit_form]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>uifilelayout</editorlayout>
  <editable>
    <field editable="1" name="calculation_point_distance"/>
    <field editable="1" name="code"/>
    <field editable="1" name="connection_node_id_end"/>
    <field editable="1" name="connection_node_id_start"/>
    <field editable="1" name="display_name"/>
    <field editable="1" name="exchange_thickness"/>
    <field editable="1" name="exchange_type"/>
    <field editable="1" name="hydraulic_conductivity_in"/>
    <field editable="1" name="hydraulic_conductivity_out"/>
    <field editable="1" name="id"/>
    <field editable="1" name="tags"/>
  </editable>
  <labelOnTop>
    <field name="calculation_point_distance" labelOnTop="0"/>
    <field name="code" labelOnTop="0"/>
    <field name="connection_node_id_end" labelOnTop="0"/>
    <field name="connection_node_id_start" labelOnTop="0"/>
    <field name="display_name" labelOnTop="0"/>
    <field name="exchange_thickness" labelOnTop="0"/>
    <field name="exchange_type" labelOnTop="0"/>
    <field name="hydraulic_conductivity_in" labelOnTop="0"/>
    <field name="hydraulic_conductivity_out" labelOnTop="0"/>
    <field name="id" labelOnTop="0"/>
    <field name="tags" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="calculation_point_distance"/>
    <field reuseLastValue="0" name="code"/>
    <field reuseLastValue="0" name="connection_node_id_end"/>
    <field reuseLastValue="0" name="connection_node_id_start"/>
    <field reuseLastValue="0" name="display_name"/>
    <field reuseLastValue="0" name="exchange_thickness"/>
    <field reuseLastValue="0" name="exchange_type"/>
    <field reuseLastValue="0" name="hydraulic_conductivity_in"/>
    <field reuseLastValue="0" name="hydraulic_conductivity_out"/>
    <field reuseLastValue="0" name="id"/>
    <field reuseLastValue="0" name="tags"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>coalesce(display_name, '') || ' (ID ' || id || ')'</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
