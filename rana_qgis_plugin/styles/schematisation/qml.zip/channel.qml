<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyLocal="1" simplifyDrawingHints="1" version="3.44.8-Solothurn" autoRefreshTime="0" minScale="0" styleCategories="AllStyleCategories" autoRefreshMode="Disabled" simplifyMaxScale="1" hasScaleBasedVisibilityFlag="0" simplifyAlgorithm="0" symbologyReferenceScale="-1" labelsEnabled="0" simplifyDrawingTol="1" maxScale="0" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endExpression="" durationField="" mode="0" endField="" startExpression="" accumulate="0" enabled="0" startField="" limitMode="0" durationUnit="min" fixedDuration="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation clamping="Terrain" customToleranceEnabled="0" type="IndividualFeatures" respectLayerSymbol="1" extrusion="0" zoffset="0" symbology="Line" binding="Centroid" zscale="1" extrusionEnabled="0" showMarkerSymbolInSurfacePlots="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol frame_rate="10" is_animated="0" type="line" alpha="1" name="" force_rhr="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" id="{689c998c-81d0-4f44-94f6-4dc57cdad4ff}" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="255,158,23,255,rgb:1,0.6196078,0.0901961,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol frame_rate="10" is_animated="0" type="fill" alpha="1" name="" force_rhr="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" id="{1ef4b093-f0ff-4975-b51e-0b582050b5f8}" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="255,158,23,255,rgb:1,0.6196078,0.0901961,1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="182,113,16,255,rgb:0.7142748,0.4425269,0.0644236,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol frame_rate="10" is_animated="0" type="marker" alpha="1" name="" force_rhr="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" id="{6c39dd5f-81da-4a6b-b695-04b81c23a214}" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="255,158,23,255,rgb:1,0.6196078,0.0901961,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="182,113,16,255,rgb:0.7142748,0.4425269,0.0644236,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="singleSymbol" forceraster="0" symbollevels="0" referencescale="-1" enableorderby="0">
    <symbols>
      <symbol frame_rate="10" is_animated="0" type="line" alpha="1" name="0" force_rhr="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" id="{786ab226-62c7-4b44-b378-fb311831fd00}" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="5,77,209,255,rgb:0.0196078,0.3019608,0.8196078,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.66"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option type="Map" name="properties">
                <Option type="Map" name="outlineWidth">
                  <Option type="bool" name="active" value="false"/>
                  <Option type="QString" name="expression" value="if(@map_scale&lt;10000, 0.66,0.3)"/>
                  <Option type="int" name="type" value="3"/>
                </Option>
              </Option>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol frame_rate="10" is_animated="0" type="line" alpha="1" name="" force_rhr="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" id="{11f32db9-f4d5-4b11-b953-7b0dc584901a}" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.26"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option type="int" name="embeddedWidgets/count" value="0"/>
      <Option type="invalid" name="variableNames"/>
      <Option type="invalid" name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="id" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="display_name" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="code" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="exchange_type" configurationFlags="NoFlag">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="" value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}"/>
              </Option>
              <Option type="Map">
                <Option type="int" name="100: Embedded" value="100"/>
              </Option>
              <Option type="Map">
                <Option type="int" name="101: Isolated" value="101"/>
              </Option>
              <Option type="Map">
                <Option type="int" name="102: Connected" value="102"/>
              </Option>
              <Option type="Map">
                <Option type="int" name="105: Double connected" value="105"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="calculation_point_distance" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
            <Option type="qlonglong" name="Max" value="1000000000000000"/>
            <Option type="qlonglong" name="Min" value="-1000000000000000"/>
            <Option type="int" name="Precision" value="3"/>
            <Option type="double" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="connection_node_id_start" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="connection_node_id_end" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="exchange_thickness" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
            <Option type="qlonglong" name="Max" value="1000000000000000"/>
            <Option type="qlonglong" name="Min" value="-1000000000000000"/>
            <Option type="int" name="Precision" value="3"/>
            <Option type="double" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="hydraulic_conductivity_in" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
            <Option type="qlonglong" name="Max" value="1000000000000000"/>
            <Option type="int" name="Min" value="0"/>
            <Option type="int" name="Precision" value="3"/>
            <Option type="double" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="hydraulic_conductivity_out" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
            <Option type="qlonglong" name="Max" value="1000000000000000"/>
            <Option type="int" name="Min" value="0"/>
            <Option type="int" name="Precision" value="3"/>
            <Option type="double" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="tags" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="ID" field="id" index="0"/>
    <alias name="Display name" field="display_name" index="1"/>
    <alias name="Code" field="code" index="2"/>
    <alias name="Exchange type" field="exchange_type" index="3"/>
    <alias name="Calculation point distance [m]" field="calculation_point_distance" index="4"/>
    <alias name="Connection node ID start" field="connection_node_id_start" index="5"/>
    <alias name="Connection node ID end" field="connection_node_id_end" index="6"/>
    <alias name="Exchange thickness [m]" field="exchange_thickness" index="7"/>
    <alias name="Hydraulic conductivity in [m/d]" field="hydraulic_conductivity_in" index="8"/>
    <alias name="Hydraulic conductivity out [m/d]" field="hydraulic_conductivity_out" index="9"/>
    <alias name="Tags" field="tags" index="10"/>
  </aliases>
  <defaults>
    <default expression="" applyOnUpdate="0" field="id"/>
    <default expression="" applyOnUpdate="0" field="display_name"/>
    <default expression="" applyOnUpdate="0" field="code"/>
    <default expression="" applyOnUpdate="0" field="exchange_type"/>
    <default expression="" applyOnUpdate="0" field="calculation_point_distance"/>
    <default expression="" applyOnUpdate="0" field="connection_node_id_start"/>
    <default expression="" applyOnUpdate="0" field="connection_node_id_end"/>
    <default expression="" applyOnUpdate="0" field="exchange_thickness"/>
    <default expression="" applyOnUpdate="0" field="hydraulic_conductivity_in"/>
    <default expression="" applyOnUpdate="0" field="hydraulic_conductivity_out"/>
    <default expression="" applyOnUpdate="0" field="tags"/>
  </defaults>
  <constraints>
    <constraint notnull_strength="1" constraints="3" field="id" unique_strength="1" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="display_name" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="code" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="exchange_type" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="calculation_point_distance" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="connection_node_id_start" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="connection_node_id_end" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="exchange_thickness" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="hydraulic_conductivity_in" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="hydraulic_conductivity_out" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="tags" unique_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="id" desc=""/>
    <constraint exp="" field="display_name" desc=""/>
    <constraint exp="" field="code" desc=""/>
    <constraint exp="" field="exchange_type" desc=""/>
    <constraint exp="" field="calculation_point_distance" desc=""/>
    <constraint exp="" field="connection_node_id_start" desc=""/>
    <constraint exp="" field="connection_node_id_end" desc=""/>
    <constraint exp="" field="exchange_thickness" desc=""/>
    <constraint exp="" field="hydraulic_conductivity_in" desc=""/>
    <constraint exp="" field="hydraulic_conductivity_out" desc=""/>
    <constraint exp="" field="tags" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="&quot;exchange_thickness&quot;" sortOrder="0">
    <columns>
      <column hidden="0" type="field" name="id" width="-1"/>
      <column hidden="0" type="field" name="code" width="-1"/>
      <column hidden="0" type="field" name="display_name" width="-1"/>
      <column hidden="0" type="field" name="connection_node_id_start" width="146"/>
      <column hidden="0" type="field" name="connection_node_id_end" width="141"/>
      <column hidden="0" type="field" name="calculation_point_distance" width="174"/>
      <column hidden="0" type="field" name="exchange_type" width="-1"/>
      <column hidden="0" type="field" name="exchange_thickness" width="158"/>
      <column hidden="0" type="field" name="hydraulic_conductivity_in" width="203"/>
      <column hidden="0" type="field" name="hydraulic_conductivity_out" width="-1"/>
      <column hidden="0" type="field" name="tags" width="-1"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">C:\Users\jonas.vanschrojenste\AppData\Roaming\Rana\QGIS3\profiles\Demo\python\plugins\threedi_schematisation_editor\forms\ui\channel.ui</editform>
  <editforminit>open_edit_form</editforminit>
  <editforminitcodesource>2</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[from threedi_schematisation_editor.utils import open_edit_form]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>uifilelayout</editorlayout>
  <editable>
    <field editable="1" name="calculation_point_distance"/>
    <field editable="1" name="code"/>
    <field editable="1" name="connection_node_id_end"/>
    <field editable="1" name="connection_node_id_start"/>
    <field editable="1" name="display_name"/>
    <field editable="1" name="exchange_thickness"/>
    <field editable="1" name="exchange_type"/>
    <field editable="1" name="hydraulic_conductivity_in"/>
    <field editable="1" name="hydraulic_conductivity_out"/>
    <field editable="1" name="id"/>
    <field editable="1" name="tags"/>
  </editable>
  <labelOnTop>
    <field name="calculation_point_distance" labelOnTop="0"/>
    <field name="code" labelOnTop="0"/>
    <field name="connection_node_id_end" labelOnTop="0"/>
    <field name="connection_node_id_start" labelOnTop="0"/>
    <field name="display_name" labelOnTop="0"/>
    <field name="exchange_thickness" labelOnTop="0"/>
    <field name="exchange_type" labelOnTop="0"/>
    <field name="hydraulic_conductivity_in" labelOnTop="0"/>
    <field name="hydraulic_conductivity_out" labelOnTop="0"/>
    <field name="id" labelOnTop="0"/>
    <field name="tags" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="calculation_point_distance"/>
    <field reuseLastValue="0" name="code"/>
    <field reuseLastValue="0" name="connection_node_id_end"/>
    <field reuseLastValue="0" name="connection_node_id_start"/>
    <field reuseLastValue="0" name="display_name"/>
    <field reuseLastValue="0" name="exchange_thickness"/>
    <field reuseLastValue="0" name="exchange_type"/>
    <field reuseLastValue="0" name="hydraulic_conductivity_in"/>
    <field reuseLastValue="0" name="hydraulic_conductivity_out"/>
    <field reuseLastValue="0" name="id"/>
    <field reuseLastValue="0" name="tags"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>coalesce(display_name, '') || ' (ID ' || id || ')'</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
