<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" simplifyDrawingTol="1" simplifyLocal="1" version="3.40.6-Bratislava" autoRefreshMode="Disabled" autoRefreshTime="0" maxScale="0" minScale="0" readOnly="0" hasScaleBasedVisibilityFlag="0" styleCategories="AllStyleCategories" labelsEnabled="0" simplifyMaxScale="1" symbologyReferenceScale="-1" simplifyAlgorithm="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal limitMode="0" endField="" startExpression="" durationField="" accumulate="0" endExpression="" durationUnit="min" mode="0" fixedDuration="0" startField="" enabled="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" extrusionEnabled="0" symbology="Line" zscale="1" binding="Centroid" type="IndividualFeatures" clamping="Terrain" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" zoffset="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol frame_rate="10" clip_to_extent="1" type="line" force_rhr="0" alpha="1" is_animated="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleLine" id="{c96acc5c-953a-486e-8b91-c553f1ecb3c6}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="243,166,178,255,rgb:0.95294117647058818,0.65098039215686276,0.69803921568627447,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol frame_rate="10" clip_to_extent="1" type="fill" force_rhr="0" alpha="1" is_animated="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleFill" id="{95eb9da3-c4ab-4a31-84e0-cdbdaf24e1e0}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="243,166,178,255,rgb:0.95294117647058818,0.65098039215686276,0.69803921568627447,1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="174,119,127,255,rgb:0.68065918974593731,0.46497291523613338,0.49858854047455559,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol frame_rate="10" clip_to_extent="1" type="marker" force_rhr="0" alpha="1" is_animated="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" id="{94c3cf54-b466-4441-b10c-3ab40ec42c56}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="243,166,178,255,rgb:0.95294117647058818,0.65098039215686276,0.69803921568627447,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="174,119,127,255,rgb:0.68065918974593731,0.46497291523613338,0.49858854047455559,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 forceraster="0" enableorderby="0" type="singleSymbol" symbollevels="0" referencescale="-1">
    <symbols>
      <symbol frame_rate="10" clip_to_extent="1" type="line" force_rhr="0" alpha="1" is_animated="0" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleLine" id="{5fb1042d-8124-4f5b-971b-35043efbe127}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="0"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="227,26,28,255,rgb:0.8901960784313725,0.10196078431372549,0.10980392156862745,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.66"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" class="SimpleLine" id="{544d6c8d-a7db-4604-9614-eefe36675d9a}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.26"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol frame_rate="10" clip_to_extent="1" type="line" force_rhr="0" alpha="1" is_animated="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleLine" id="{9c28c056-d616-49bf-95ce-4d6dfaf7ebc8}" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.26"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option type="int" name="embeddedWidgets/count" value="0"/>
      <Option type="invalid" name="variableNames"/>
      <Option type="invalid" name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="id">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="code">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="display_name">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="crest_level">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="crest_type">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="friction_value">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="friction_type">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="discharge_coefficient_positive">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="discharge_coefficient_negative">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="sewerage">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="external">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="connection_node_id_start">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="connection_node_id_end">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_table">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_shape">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_width">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cross_section_height">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="material_id">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="id" name="" index="0"/>
    <alias field="code" name="" index="1"/>
    <alias field="display_name" name="" index="2"/>
    <alias field="crest_level" name="" index="3"/>
    <alias field="crest_type" name="" index="4"/>
    <alias field="friction_value" name="" index="5"/>
    <alias field="friction_type" name="" index="6"/>
    <alias field="discharge_coefficient_positive" name="" index="7"/>
    <alias field="discharge_coefficient_negative" name="" index="8"/>
    <alias field="sewerage" name="" index="9"/>
    <alias field="external" name="" index="10"/>
    <alias field="connection_node_id_start" name="" index="11"/>
    <alias field="connection_node_id_end" name="" index="12"/>
    <alias field="cross_section_table" name="" index="13"/>
    <alias field="cross_section_shape" name="" index="14"/>
    <alias field="cross_section_width" name="" index="15"/>
    <alias field="cross_section_height" name="" index="16"/>
    <alias field="tags" name="" index="17"/>
    <alias field="material_id" name="" index="18"/>
  </aliases>
  <splitPolicies>
    <policy field="id" policy="Duplicate"/>
    <policy field="code" policy="Duplicate"/>
    <policy field="display_name" policy="Duplicate"/>
    <policy field="crest_level" policy="Duplicate"/>
    <policy field="crest_type" policy="Duplicate"/>
    <policy field="friction_value" policy="Duplicate"/>
    <policy field="friction_type" policy="Duplicate"/>
    <policy field="discharge_coefficient_positive" policy="Duplicate"/>
    <policy field="discharge_coefficient_negative" policy="Duplicate"/>
    <policy field="sewerage" policy="Duplicate"/>
    <policy field="external" policy="Duplicate"/>
    <policy field="connection_node_id_start" policy="Duplicate"/>
    <policy field="connection_node_id_end" policy="Duplicate"/>
    <policy field="cross_section_table" policy="Duplicate"/>
    <policy field="cross_section_shape" policy="Duplicate"/>
    <policy field="cross_section_width" policy="Duplicate"/>
    <policy field="cross_section_height" policy="Duplicate"/>
    <policy field="tags" policy="Duplicate"/>
    <policy field="material_id" policy="Duplicate"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy field="id" policy="Duplicate"/>
    <policy field="code" policy="Duplicate"/>
    <policy field="display_name" policy="Duplicate"/>
    <policy field="crest_level" policy="Duplicate"/>
    <policy field="crest_type" policy="Duplicate"/>
    <policy field="friction_value" policy="Duplicate"/>
    <policy field="friction_type" policy="Duplicate"/>
    <policy field="discharge_coefficient_positive" policy="Duplicate"/>
    <policy field="discharge_coefficient_negative" policy="Duplicate"/>
    <policy field="sewerage" policy="Duplicate"/>
    <policy field="external" policy="Duplicate"/>
    <policy field="connection_node_id_start" policy="Duplicate"/>
    <policy field="connection_node_id_end" policy="Duplicate"/>
    <policy field="cross_section_table" policy="Duplicate"/>
    <policy field="cross_section_shape" policy="Duplicate"/>
    <policy field="cross_section_width" policy="Duplicate"/>
    <policy field="cross_section_height" policy="Duplicate"/>
    <policy field="tags" policy="Duplicate"/>
    <policy field="material_id" policy="Duplicate"/>
  </duplicatePolicies>
  <defaults>
    <default field="id" expression="" applyOnUpdate="0"/>
    <default field="code" expression="" applyOnUpdate="0"/>
    <default field="display_name" expression="" applyOnUpdate="0"/>
    <default field="crest_level" expression="" applyOnUpdate="0"/>
    <default field="crest_type" expression="" applyOnUpdate="0"/>
    <default field="friction_value" expression="" applyOnUpdate="0"/>
    <default field="friction_type" expression="" applyOnUpdate="0"/>
    <default field="discharge_coefficient_positive" expression="" applyOnUpdate="0"/>
    <default field="discharge_coefficient_negative" expression="" applyOnUpdate="0"/>
    <default field="sewerage" expression="" applyOnUpdate="0"/>
    <default field="external" expression="" applyOnUpdate="0"/>
    <default field="connection_node_id_start" expression="" applyOnUpdate="0"/>
    <default field="connection_node_id_end" expression="" applyOnUpdate="0"/>
    <default field="cross_section_table" expression="" applyOnUpdate="0"/>
    <default field="cross_section_shape" expression="" applyOnUpdate="0"/>
    <default field="cross_section_width" expression="" applyOnUpdate="0"/>
    <default field="cross_section_height" expression="" applyOnUpdate="0"/>
    <default field="tags" expression="" applyOnUpdate="0"/>
    <default field="material_id" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="id" unique_strength="1" exp_strength="0" constraints="3" notnull_strength="1"/>
    <constraint field="code" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="display_name" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="crest_level" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="crest_type" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="friction_value" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="friction_type" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="discharge_coefficient_positive" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="discharge_coefficient_negative" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="sewerage" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="external" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="connection_node_id_start" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="connection_node_id_end" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_table" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_shape" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_width" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="cross_section_height" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="tags" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="material_id" unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="id" exp="" desc=""/>
    <constraint field="code" exp="" desc=""/>
    <constraint field="display_name" exp="" desc=""/>
    <constraint field="crest_level" exp="" desc=""/>
    <constraint field="crest_type" exp="" desc=""/>
    <constraint field="friction_value" exp="" desc=""/>
    <constraint field="friction_type" exp="" desc=""/>
    <constraint field="discharge_coefficient_positive" exp="" desc=""/>
    <constraint field="discharge_coefficient_negative" exp="" desc=""/>
    <constraint field="sewerage" exp="" desc=""/>
    <constraint field="external" exp="" desc=""/>
    <constraint field="connection_node_id_start" exp="" desc=""/>
    <constraint field="connection_node_id_end" exp="" desc=""/>
    <constraint field="cross_section_table" exp="" desc=""/>
    <constraint field="cross_section_shape" exp="" desc=""/>
    <constraint field="cross_section_width" exp="" desc=""/>
    <constraint field="cross_section_height" exp="" desc=""/>
    <constraint field="tags" exp="" desc=""/>
    <constraint field="material_id" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column width="-1" type="field" hidden="0" name="id"/>
      <column width="-1" type="field" hidden="0" name="code"/>
      <column width="-1" type="field" hidden="0" name="display_name"/>
      <column width="-1" type="field" hidden="0" name="tags"/>
      <column width="-1" type="field" hidden="0" name="crest_level"/>
      <column width="-1" type="field" hidden="0" name="crest_type"/>
      <column width="-1" type="field" hidden="0" name="friction_value"/>
      <column width="-1" type="field" hidden="0" name="friction_type"/>
      <column width="-1" type="field" hidden="0" name="discharge_coefficient_positive"/>
      <column width="-1" type="field" hidden="0" name="discharge_coefficient_negative"/>
      <column width="-1" type="field" hidden="0" name="material_id"/>
      <column width="-1" type="field" hidden="0" name="sewerage"/>
      <column width="-1" type="field" hidden="0" name="external"/>
      <column width="-1" type="field" hidden="0" name="connection_node_id_start"/>
      <column width="-1" type="field" hidden="0" name="connection_node_id_end"/>
      <column width="-1" type="field" hidden="0" name="cross_section_shape"/>
      <column width="-1" type="field" hidden="0" name="cross_section_width"/>
      <column width="-1" type="field" hidden="0" name="cross_section_height"/>
      <column width="-1" type="field" hidden="0" name="cross_section_table"/>
      <column width="-1" type="actions" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="code"/>
    <field editable="1" name="connection_node_id_end"/>
    <field editable="1" name="connection_node_id_start"/>
    <field editable="1" name="crest_level"/>
    <field editable="1" name="crest_type"/>
    <field editable="1" name="cross_section_height"/>
    <field editable="1" name="cross_section_shape"/>
    <field editable="1" name="cross_section_table"/>
    <field editable="1" name="cross_section_width"/>
    <field editable="1" name="discharge_coefficient_negative"/>
    <field editable="1" name="discharge_coefficient_positive"/>
    <field editable="1" name="display_name"/>
    <field editable="1" name="external"/>
    <field editable="1" name="friction_type"/>
    <field editable="1" name="friction_value"/>
    <field editable="1" name="id"/>
    <field editable="1" name="material_id"/>
    <field editable="1" name="sewerage"/>
    <field editable="1" name="tags"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="code"/>
    <field labelOnTop="0" name="connection_node_id_end"/>
    <field labelOnTop="0" name="connection_node_id_start"/>
    <field labelOnTop="0" name="crest_level"/>
    <field labelOnTop="0" name="crest_type"/>
    <field labelOnTop="0" name="cross_section_height"/>
    <field labelOnTop="0" name="cross_section_shape"/>
    <field labelOnTop="0" name="cross_section_table"/>
    <field labelOnTop="0" name="cross_section_width"/>
    <field labelOnTop="0" name="discharge_coefficient_negative"/>
    <field labelOnTop="0" name="discharge_coefficient_positive"/>
    <field labelOnTop="0" name="display_name"/>
    <field labelOnTop="0" name="external"/>
    <field labelOnTop="0" name="friction_type"/>
    <field labelOnTop="0" name="friction_value"/>
    <field labelOnTop="0" name="id"/>
    <field labelOnTop="0" name="material_id"/>
    <field labelOnTop="0" name="sewerage"/>
    <field labelOnTop="0" name="tags"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="code"/>
    <field reuseLastValue="0" name="connection_node_id_end"/>
    <field reuseLastValue="0" name="connection_node_id_start"/>
    <field reuseLastValue="0" name="crest_level"/>
    <field reuseLastValue="0" name="crest_type"/>
    <field reuseLastValue="0" name="cross_section_height"/>
    <field reuseLastValue="0" name="cross_section_shape"/>
    <field reuseLastValue="0" name="cross_section_table"/>
    <field reuseLastValue="0" name="cross_section_width"/>
    <field reuseLastValue="0" name="discharge_coefficient_negative"/>
    <field reuseLastValue="0" name="discharge_coefficient_positive"/>
    <field reuseLastValue="0" name="display_name"/>
    <field reuseLastValue="0" name="external"/>
    <field reuseLastValue="0" name="friction_type"/>
    <field reuseLastValue="0" name="friction_value"/>
    <field reuseLastValue="0" name="id"/>
    <field reuseLastValue="0" name="material_id"/>
    <field reuseLastValue="0" name="sewerage"/>
    <field reuseLastValue="0" name="tags"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>coalesce(display_name, '') || ' (ID ' || id || ')'</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
